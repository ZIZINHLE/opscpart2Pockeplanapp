package com.example.pocketplanapp.model

data class SavingsGoal(
    val goalName: String,
    val targetAmount: Double,
    val currentAmount: Double
)