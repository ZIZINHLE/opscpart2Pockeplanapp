package com.example.pocketplanapp

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pocketplanapp.data.BudgetStorage
import com.example.pocketplanapp.model.BudgetTransaction
import com.example.pocketplanapp.model.SavingsGoal
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PocketPlanApp() }
    }
}

enum class Screen {
    Splash, Login, Register, Home, AddIncome, AddExpense, Transactions, Savings, TotalSpent, Settings
}

@Composable
fun PocketPlanApp() {
    val context = LocalContext.current

    var currentUserEmail by remember { mutableStateOf("") }
    var storage by remember { mutableStateOf<BudgetStorage?>(null) }

    var currentScreen by remember { mutableStateOf(Screen.Splash) }
    val transactions = remember { mutableStateListOf<BudgetTransaction>() }
    var savingsGoal by remember {
        mutableStateOf(
            SavingsGoal(
                goalName = "No goal set yet",
                targetAmount = 0.0,
                currentAmount = 0.0
            )
        )
    }

    fun loadUserData() {
        val activeStorage = storage
        if (activeStorage != null) {
            transactions.clear()
            transactions.addAll(activeStorage.getTransactions())
            savingsGoal = activeStorage.getSavingsGoal()
        }
    }

    LaunchedEffect(Unit) {
        delay(1500)
        currentScreen = Screen.Login
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.White) {
        when (currentScreen) {
            Screen.Splash -> SplashScreen()

            Screen.Login -> LoginScreen(
                onLogin = { email ->
                    currentUserEmail = email.trim().lowercase()
                    storage = BudgetStorage(context, currentUserEmail)
                    loadUserData()
                    Toast.makeText(context, "Login successful", Toast.LENGTH_SHORT).show()
                    currentScreen = Screen.Home
                },
                onRegister = { currentScreen = Screen.Register }
            )

            Screen.Register -> RegisterScreen(
                onCreate = { email ->
                    currentUserEmail = email.trim().lowercase()
                    storage = BudgetStorage(context, currentUserEmail)
                    loadUserData()
                    Toast.makeText(context, "Account created successfully", Toast.LENGTH_SHORT).show()
                    currentScreen = Screen.Home
                },
                onLogin = { currentScreen = Screen.Login }
            )

            Screen.Home -> HomeDashboard(
                transactions = transactions,
                savingsGoal = savingsGoal,
                currentUserEmail = currentUserEmail,
                onNavigate = { currentScreen = it }
            )

            Screen.AddIncome -> AddIncomeScreen(
                onBack = { currentScreen = Screen.Home },
                onSave = { source, amount ->
                    storage?.addTransaction(source, amount, "Income", "Income")
                    loadUserData()
                    Toast.makeText(context, "Income added successfully", Toast.LENGTH_SHORT).show()
                    currentScreen = Screen.Home
                }
            )

            Screen.AddExpense -> AddExpenseScreen(
                onBack = { currentScreen = Screen.Home },
                onSave = { name, amount, category, receiptUri ->
                    storage?.addTransaction(name, amount, category, "Expense", receiptUri)
                    loadUserData()
                    Toast.makeText(context, "Expense added successfully", Toast.LENGTH_SHORT).show()
                    currentScreen = Screen.Home
                }
            )

            Screen.Transactions -> TransactionsScreen(
                transactions = transactions,
                onBack = { currentScreen = Screen.Home },
                onDelete = { id ->
                    storage?.deleteTransaction(id)
                    loadUserData()
                    Toast.makeText(context, "Transaction deleted", Toast.LENGTH_SHORT).show()
                }
            )

            Screen.Savings -> SavingsGoalScreen(
                savingsGoal = savingsGoal,
                onBack = { currentScreen = Screen.Home },
                onSave = { goal ->
                    storage?.saveSavingsGoal(goal)
                    loadUserData()
                    Toast.makeText(context, "Savings goal saved", Toast.LENGTH_SHORT).show()
                    currentScreen = Screen.Home
                }
            )

            Screen.TotalSpent -> TotalSpentScreen(
                transactions = transactions,
                onBack = { currentScreen = Screen.Home }
            )

            Screen.Settings -> SettingsScreen(
                currentUserEmail = currentUserEmail,
                onBack = { currentScreen = Screen.Home },
                onClearData = {
                    storage?.clearUserData()
                    loadUserData()
                    Toast.makeText(context, "All data cleared", Toast.LENGTH_SHORT).show()
                    currentScreen = Screen.Home
                },
                onLogout = {
                    currentUserEmail = ""
                    storage = null
                    transactions.clear()
                    savingsGoal = SavingsGoal("No goal set yet", 0.0, 0.0)
                    Toast.makeText(context, "Logged out", Toast.LENGTH_SHORT).show()
                    currentScreen = Screen.Login
                }
            )
        }
    }
}

@Composable
fun SplashScreen() {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Pocket Plan Logo",
                modifier = Modifier.size(130.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text("Pocket Plan", fontSize = 34.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(8.dp))

            Text("Smart budgeting for everyday life", color = Color(0xFF2F80ED))
        }
    }
}

@Composable
fun LoginScreen(
    onLogin: (String) -> Unit,
    onRegister: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "Logo",
            modifier = Modifier.size(75.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text("Welcome back", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Log in to view your personal budget.", color = Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        InputField("Email", email, KeyboardType.Email) { email = it }
        PasswordField("Password", password) { password = it }

        AppButton("Log In") {
            if (email.isBlank() || password.isBlank()) {
                Toast.makeText(context, "Fill in all fields", Toast.LENGTH_SHORT).show()
            } else {
                onLogin(email)
            }
        }

        TextButton(
            onClick = onRegister,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Create account")
        }
    }
}

@Composable
fun RegisterScreen(
    onCreate: (String) -> Unit,
    onLogin: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "Logo",
            modifier = Modifier.size(75.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text("Create account", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("Start tracking your money separately from other users.", color = Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        InputField("Full Name", name) { name = it }
        InputField("Email", email, KeyboardType.Email) { email = it }
        PasswordField("Password", password) { password = it }
        PasswordField("Confirm Password", confirmPassword) { confirmPassword = it }

        AppButton("Create Account") {
            if (name.isBlank() || email.isBlank() || password.isBlank()) {
                Toast.makeText(context, "Fill in all fields", Toast.LENGTH_SHORT).show()
            } else if (password != confirmPassword) {
                Toast.makeText(context, "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                onCreate(email)
            }
        }

        TextButton(
            onClick = onLogin,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Text("Already have an account?")
        }
    }
}

@Composable
fun HomeDashboard(
    transactions: SnapshotStateList<BudgetTransaction>,
    savingsGoal: SavingsGoal,
    currentUserEmail: String,
    onNavigate: (Screen) -> Unit
) {
    val income = transactions.filter { it.type == "Income" }.sumOf { it.amount }
    val expenses = transactions.filter { it.type == "Expense" }.sumOf { it.amount }
    val balance = income - expenses
    val budgetLimit = 5000.0

    val budgetUsed = if (budgetLimit > 0) {
        (expenses / budgetLimit).coerceIn(0.0, 1.0)
    } else 0.0

    val budgetMessage = when {
        expenses >= budgetLimit -> "Over budget"
        expenses >= budgetLimit * 0.8 -> "Close to budget limit"
        else -> "Budget healthy"
    }

    val savingsProgress = if (savingsGoal.targetAmount > 0) {
        (savingsGoal.currentAmount / savingsGoal.targetAmount).coerceIn(0.0, 1.0)
    } else 0.0

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Hello 👋", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(currentUserEmail, color = Color.Gray, fontSize = 13.sp)
                }

                IconButton(onClick = { onNavigate(Screen.Settings) }) {
                    Text("⚙️", fontSize = 24.sp)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                modifier = Modifier.fillMaxWidth().height(205.dp),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E3A8A))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Remaining Balance", color = Color.White.copy(alpha = 0.85f))

                    Text(
                        "R %.2f".format(balance),
                        color = Color.White,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    LinearProgressIndicator(
                        progress = { budgetUsed.toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFFFFC107),
                        trackColor = Color.White.copy(alpha = 0.25f)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(budgetMessage, color = Color.White)

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MiniBudgetBox("Income", "R %.2f".format(income))
                        MiniBudgetBox("Spent", "R %.2f".format(expenses))
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SmallAction("➕", "Income") { onNavigate(Screen.AddIncome) }
                SmallAction("💸", "Expense") { onNavigate(Screen.AddExpense) }
                SmallAction("🎯", "Goals") { onNavigate(Screen.Savings) }
                SmallAction("📋", "Records") { onNavigate(Screen.Transactions) }
            }

            Spacer(modifier = Modifier.height(18.dp))

            AppButton("View Total Spent") { onNavigate(Screen.TotalSpent) }

            Spacer(modifier = Modifier.height(22.dp))

            Text("Savings Goal", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7FA))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(savingsGoal.goalName, fontWeight = FontWeight.Bold)

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        "Saved: R %.2f / R %.2f".format(
                            savingsGoal.currentAmount,
                            savingsGoal.targetAmount
                        ),
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { savingsProgress.toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFFFFC107)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("${(savingsProgress * 100).toInt()}% completed")
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Text("Category Totals", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(10.dp))
            CategoryTotalsCard(transactions)
        }
    }
}

@Composable
fun SettingsScreen(
    currentUserEmail: String,
    onBack: () -> Unit,
    onClearData: () -> Unit,
    onLogout: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("Back") }

        Text("Settings", fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("Logged in as $currentUserEmail", color = Color.Gray)

        Spacer(modifier = Modifier.height(28.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7FA))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text("Account actions", fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onClearData,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA000))
                ) {
                    Text("Clear All My Data")
                }

                Spacer(modifier = Modifier.height(10.dp))

                Button(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                ) {
                    Text("Logout")
                }
            }
        }
    }
}

@Composable
fun CategoryTotalsCard(transactions: List<BudgetTransaction>) {
    val expenses = transactions.filter { it.type == "Expense" }
    val categoryTotals = expenses.groupBy { it.category }.mapValues { entry ->
        entry.value.sumOf { it.amount }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7FA))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            if (categoryTotals.isEmpty()) {
                Text("No category spending yet.", color = Color.Gray)
            } else {
                categoryTotals.forEach { (category, total) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(category)
                        Text("R %.2f".format(total), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AddIncomeScreen(
    onBack: () -> Unit,
    onSave: (String, Double) -> Unit
) {
    var source by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    val context = LocalContext.current

    FormLayout("Add Income", onBack) {
        InputField("Income Source", source) { source = it }
        InputField("Amount", amount, KeyboardType.Number) { amount = it }

        AppButton("Save Income") {
            val enteredAmount = amount.toDoubleOrNull()
            if (source.isBlank() || enteredAmount == null || enteredAmount <= 0) {
                Toast.makeText(context, "Enter valid details", Toast.LENGTH_SHORT).show()
            } else {
                onSave(source, enteredAmount)
            }
        }
    }
}

@Composable
fun AddExpenseScreen(
    onBack: () -> Unit,
    onSave: (String, Double, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Food") }
    var expanded by remember { mutableStateOf(false) }
    var receiptUri by remember { mutableStateOf("") }
    val context = LocalContext.current

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        receiptUri = uri?.toString() ?: ""
    }

    val categories = listOf("Food", "Transport", "School", "Entertainment", "Personal", "Other")

    FormLayout("Add Expense", onBack) {
        InputField("Expense Name", name) { name = it }
        InputField("Amount", amount, KeyboardType.Number) { amount = it }

        Box {
            OutlinedButton(
                onClick = { expanded = true },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp)
            ) {
                Text("Category: $category")
            }

            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                categories.forEach {
                    DropdownMenuItem(
                        text = { Text(it) },
                        onClick = {
                            category = it
                            expanded = false
                        }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedButton(
            onClick = { imagePicker.launch("image/*") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text(if (receiptUri.isBlank()) "Upload Receipt" else "Receipt Selected")
        }

        if (receiptUri.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            ReceiptPreview(receiptUri)
        }

        AppButton("Save Expense") {
            val enteredAmount = amount.toDoubleOrNull()
            if (name.isBlank() || enteredAmount == null || enteredAmount <= 0) {
                Toast.makeText(context, "Enter valid expense details", Toast.LENGTH_SHORT).show()
            } else {
                onSave(name, enteredAmount, category, receiptUri)
            }
        }
    }
}

@Composable
fun TransactionsScreen(
    transactions: SnapshotStateList<BudgetTransaction>,
    onBack: () -> Unit,
    onDelete: (Long) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("Back") }

        Text("Transactions", fontSize = 28.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        if (transactions.isEmpty()) {
            Text("No transactions yet.", color = Color.Gray)
        } else {
            LazyColumn {
                items(transactions) { transaction ->
                    TransactionCard(transaction, onDelete = { onDelete(transaction.id) })
                }
            }
        }
    }
}

@Composable
fun TransactionCard(
    transaction: BudgetTransaction,
    onDelete: (() -> Unit)?
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 7.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7FA))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(transaction.name, fontWeight = FontWeight.Bold)
            Text("Type: ${transaction.type}")
            Text("Category: ${transaction.category}")
            Text("Amount: R %.2f".format(transaction.amount))
            Text("Date: ${transaction.date}", color = Color.Gray)

            if (transaction.receiptUri.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Receipt attached", color = Color(0xFF2F80ED))
                ReceiptPreview(transaction.receiptUri)
            }

            if (onDelete != null) {
                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = onDelete,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                ) {
                    Text("Delete")
                }
            }
        }
    }
}

@Composable
fun ReceiptPreview(receiptUri: String) {
    val context = LocalContext.current
    val bitmap = remember(receiptUri) {
        try {
            val inputStream = context.contentResolver.openInputStream(Uri.parse(receiptUri))
            BitmapFactory.decodeStream(inputStream)
        } catch (e: Exception) {
            null
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = "Receipt image",
            modifier = Modifier.fillMaxWidth().height(150.dp),
            contentScale = ContentScale.Crop
        )
    } else {
        Text("Receipt image could not be loaded.", color = Color.Gray)
    }
}

@Composable
fun SavingsGoalScreen(
    savingsGoal: SavingsGoal,
    onBack: () -> Unit,
    onSave: (SavingsGoal) -> Unit
) {
    var goalName by remember { mutableStateOf(savingsGoal.goalName) }
    var targetAmount by remember { mutableStateOf(savingsGoal.targetAmount.toString()) }
    var currentAmount by remember { mutableStateOf(savingsGoal.currentAmount.toString()) }
    val context = LocalContext.current

    FormLayout("Savings Goal", onBack) {
        InputField("Goal Name", goalName) { goalName = it }
        InputField("Target Amount", targetAmount, KeyboardType.Number) { targetAmount = it }
        InputField("Current Amount", currentAmount, KeyboardType.Number) { currentAmount = it }

        AppButton("Save Goal") {
            val target = targetAmount.toDoubleOrNull()
            val current = currentAmount.toDoubleOrNull()

            if (goalName.isBlank() || target == null || current == null || target <= 0 || current < 0) {
                Toast.makeText(context, "Enter valid goal details", Toast.LENGTH_SHORT).show()
            } else {
                onSave(SavingsGoal(goalName, target, current))
            }
        }
    }
}

@Composable
fun TotalSpentScreen(
    transactions: SnapshotStateList<BudgetTransaction>,
    onBack: () -> Unit
) {
    val expenses = transactions.filter { it.type == "Expense" }
    val totalSpent = expenses.sumOf { it.amount }

    val categoryTotals = expenses.groupBy { it.category }.mapValues { entry ->
        entry.value.sumOf { it.amount }
    }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("Back") }

        Text("Total Spent", fontSize = 30.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(20.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E3A8A))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("You spent", color = Color.White)
                Text(
                    "R %.2f".format(totalSpent),
                    color = Color.White,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("Spending by Category", fontSize = 20.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(10.dp))

        CategoryTotalsCard(transactions)
        Spacer(modifier = Modifier.height(12.dp))
        CategoryBarGraph(categoryTotals)
    }
}

@Composable
fun CategoryBarGraph(categoryTotals: Map<String, Double>) {
    val maxAmount = categoryTotals.values.maxOrNull() ?: 1.0

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F7FA))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            if (categoryTotals.isEmpty()) {
                Text("No spending data yet.", color = Color.Gray)
            } else {
                categoryTotals.forEach { (category, amount) ->
                    Text(category, fontWeight = FontWeight.SemiBold)

                    LinearProgressIndicator(
                        progress = { (amount / maxAmount).toFloat() },
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF2F80ED)
                    )

                    Text("R %.2f".format(amount), color = Color.Gray)

                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
fun FormLayout(
    title: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(20.dp)) {
        item {
            Column {
                TextButton(onClick = onBack) { Text("Back") }

                Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(20.dp))

                content()
            }
        }
    }
}

@Composable
fun MiniBudgetBox(title: String, value: String) {
    Column(
        modifier = Modifier
            .background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Text(title, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
        Text(value, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SmallAction(icon: String, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Button(
            onClick = onClick,
            modifier = Modifier.size(70.dp),
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF1F5F9))
        ) {
            Text(icon, fontSize = 24.sp)
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(label, fontSize = 12.sp)
    }
}

@Composable
fun InputField(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        shape = RoundedCornerShape(18.dp)
    )
}

@Composable
fun PasswordField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        visualTransformation = PasswordVisualTransformation(),
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        shape = RoundedCornerShape(18.dp)
    )
}

@Composable
fun AppButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp).height(56.dp),
        shape = RoundedCornerShape(18.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F80ED))
    ) {
        Text(text, fontSize = 16.sp, color = Color.White, fontWeight = FontWeight.Bold)
    }
}