package com.example.pocketplanapp.model

data class BudgetTransaction(
    val id: Long,
    val name: String,
    val amount: Double,
    val category: String,
    val type: String,
    val date: String,
    val dateMillis: Long,
    val receiptUri: String = ""
)