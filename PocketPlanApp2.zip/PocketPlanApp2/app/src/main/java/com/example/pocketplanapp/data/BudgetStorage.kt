package com.example.pocketplanapp.data

import android.content.Context
import com.example.pocketplanapp.model.BudgetTransaction
import com.example.pocketplanapp.model.SavingsGoal
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BudgetStorage(context: Context, private val userEmail: String) {

    private val prefs = context.getSharedPreferences("pocket_plan_data", Context.MODE_PRIVATE)

    private fun key(name: String): String {
        return "${userEmail}_$name"
    }

    fun getTransactions(): MutableList<BudgetTransaction> {
        val jsonString = prefs.getString(key("transactions"), "[]")
        val jsonArray = JSONArray(jsonString)
        val list = mutableListOf<BudgetTransaction>()

        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)

            list.add(
                BudgetTransaction(
                    id = item.getLong("id"),
                    name = item.getString("name"),
                    amount = item.getDouble("amount"),
                    category = item.getString("category"),
                    type = item.getString("type"),
                    date = item.getString("date"),
                    dateMillis = item.optLong("dateMillis", System.currentTimeMillis()),
                    receiptUri = item.optString("receiptUri", "")
                )
            )
        }

        return list
    }

    fun addTransaction(
        name: String,
        amount: Double,
        category: String,
        type: String,
        receiptUri: String = ""
    ) {
        val transactions = getTransactions()
        val now = System.currentTimeMillis()
        val date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(now))

        transactions.add(
            BudgetTransaction(
                id = now,
                name = name,
                amount = amount,
                category = category,
                type = type,
                date = date,
                dateMillis = now,
                receiptUri = receiptUri
            )
        )

        saveTransactions(transactions)
    }

    fun deleteTransaction(id: Long) {
        val transactions = getTransactions().filter { it.id != id }.toMutableList()
        saveTransactions(transactions)
    }

    private fun saveTransactions(transactions: MutableList<BudgetTransaction>) {
        val jsonArray = JSONArray()

        transactions.forEach { transaction ->
            val obj = JSONObject()
            obj.put("id", transaction.id)
            obj.put("name", transaction.name)
            obj.put("amount", transaction.amount)
            obj.put("category", transaction.category)
            obj.put("type", transaction.type)
            obj.put("date", transaction.date)
            obj.put("dateMillis", transaction.dateMillis)
            obj.put("receiptUri", transaction.receiptUri)
            jsonArray.put(obj)
        }

        prefs.edit().putString(key("transactions"), jsonArray.toString()).apply()
    }

    fun saveSavingsGoal(goal: SavingsGoal) {
        prefs.edit()
            .putString(key("goalName"), goal.goalName)
            .putFloat(key("targetAmount"), goal.targetAmount.toFloat())
            .putFloat(key("currentAmount"), goal.currentAmount.toFloat())
            .apply()
    }

    fun getSavingsGoal(): SavingsGoal {
        return SavingsGoal(
            goalName = prefs.getString(key("goalName"), "No goal set yet") ?: "No goal set yet",
            targetAmount = prefs.getFloat(key("targetAmount"), 0f).toDouble(),
            currentAmount = prefs.getFloat(key("currentAmount"), 0f).toDouble()
        )
    }

    fun clearUserData() {
        prefs.edit()
            .remove(key("transactions"))
            .remove(key("goalName"))
            .remove(key("targetAmount"))
            .remove(key("currentAmount"))
            .apply()
    }
}